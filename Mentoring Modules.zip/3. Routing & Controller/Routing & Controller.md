📌 Tujuan Bab Ini:
- Memahami sistem routing modern di CI4
- Migrasi controller CI3 ke format CI4
- Contoh implementasi lengkap
- Best practice + tips

### A. ROUTING DI CI4

🔹 File Routing: app/Config/Routes.php
🔸 Routing Default: $routes->get('/', 'Home::index');
Artinya: URL / akan memanggil Home.php pada method index() di folder app/Controllers/.

Jenis Routing yang Didukung:

| Tipe              | Contoh                                                        |
| ----------------- | ------------------------------------------------------------- |
| `GET`             | `$routes->get('profile', 'User::profile');`                   |
| `POST`            | `$routes->post('user/save', 'User::save');`                   |
| `ANY`             | `$routes->match(['get', 'post'], 'search', 'Search::index');` |
| `RESOURCE` (REST) | `$routes->resource('users');`                                 |
| `GROUP`           |  
`$routes->group('admin', ['filter' => 'auth'], function($routes) {
    $routes->get('dashboard', 'Admin\Dashboard::index');
});`                                               |

Contoh Routing Group:
```
$routes->group('admin', ['filter' => 'auth'], function($routes) {
    $routes->get('dashboard', 'Admin\Dashboard::index');
});

```
Ini memanggil app/Controllers/Admin/Dashboard.php

Dynamic Parameter:
```
$routes->get('blog/(:segment)', 'Blog::view/$1');
$routes->get('user/(:num)', 'User::detail/$1');

```
(:segment) cocok untuk string/slug, (:num) untuk angka

Filter (Middleware):
Contoh filter auth:
```
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'auth'])
```


| Wildcard      | Keterangan                                                       | Contoh route                                        |
| ------------- | ---------------------------------------------------------------- | --------------------------------------------------- |
| `(:num)`      | Hanya angka (`0-9`)                                              | `$routes->get('user/(:num)', 'User::detail/$1');`   |
| `(:segment)`  | Satu segmen URL (tanpa `/`), bisa huruf, angka, dash, underscore | `$routes->get('blog/(:segment)', 'Blog::view/$1');` |
| `(:alpha)`    | Hanya huruf (`a-z`, `A-Z`)                                       | `$routes->get('name/(:alpha)', 'User::byName/$1');` |
| `(:alphanum)` | Huruf dan angka (`a-z`, `A-Z`, `0-9`)                            | `$routes->get('tag/(:alphanum)', 'Tag::show/$1');`  |
| `(:any)`      | Segala karakter (kecuali `/`)                                    | `$routes->get('file/(:any)', 'File::open/$1');`     |
| `(:all)`      | Segala karakter **termasuk slash** (`/`), cocok untuk path/file  | `$routes->get('page/(:all)', 'Page::load/$1');`     |



### B. CONTROLLER DI CI4
🔹 Struktur:
- Semua controller berada di: app/Controllers/
- Controller harus pakai namespace dan biasanya extend BaseController

🔸 Contoh Sederhana:
```
<?php
namespace App\Controllers;

class Home extends BaseController {
    public function index() {
        return view('welcome_message');
    }
}

```

🔹 Controller Dengan Parameter:
```
public function show($id) {
    echo "User ID: " . $id;
}
```

Pastikan routing kamu punya:
```
$routes->get('user/(:num)', 'User::show/$1');
```

Nested Controller (Folder):
- Misalnya pada: app/Controllers/Admin/Dashboard.php
- Isi: 
```
namespace App\Controllers\Admin;

class Dashboard extends \App\Controllers\BaseController {
    public function index() {
        return "Admin Dashboard";
    }
}

```

- Routing
```
$routes->get('admin/dashboard', 'Admin\Dashboard::index');

```

- Cek Semua Routing: php spark routes

### C. Migrasi Controller dari CI3 ke CI4

🔸 CI3:
```
class Blog extends CI_Controller {
    public function index() {
        $this->load->view('blog');
    }
}
```

🔸 CI4:
```
namespace App\Controllers;

class Blog extends BaseController {
    public function index() {
        return view('blog');
    }
}

```

### D. Practice
- Tambahkan ke app/Config/Constants.php
```
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https://'.$_SERVER['HTTP_HOST'] : 'http://'.$_SERVER['HTTP_HOST'];
defined('BASE') || define('BASE',$protocol);
```

- Edit app/Config/App.php
-- public string $baseURL = BASE;
-- public string $indexPage = '';

- Buat file di Views :
-- landing.php
-- login.php

- Buat Controller Admin
-- php spark make:controller Admin 
-- Kemudian isi dengan return view('pages/admin/dashboard', ['title' => 'Admin Dashboard']);


### E. Best Practice Routing & Controller

| Tips                         | Penjelasan                               |
| ---------------------------- | ---------------------------------------- |
| Gunakan namespace            | Hindari class conflict dan lebih modular |
| Gunakan controller RESTful   | Untuk API, gunakan `$routes->resource()` |
| Pisahkan admin/public        | Gunakan route group + folder             |
| Hindari anonymous controller | Simpan semua controller di file terpisah |

