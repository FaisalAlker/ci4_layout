## Installation

A. Requirement Tools
- Download Laragon [Laragon](https://laragon.org/download)
- Create Directory D:\Local_Server
- Install Laragon in D:\Local_Server\laragon

- Press Windows =>type=> System Environment => Environment Variable 
- Arahkan ke Path dibagian System Variables => Klik New 
- Add PHP path : D:\Local_Server\Laragon\bin\php\php-8.3.16-Win32-vs16-x64\
- Add Composer path : D:\Local_Server\Laragon\bin\composer\

- Klik Kanan pada Laragon => Klik php.ini
- Open File php.ini
- Find zip => extension=zip => remove ;

- Disable Apache
- Set Nginx SSL Port ke 443 => Centang Enable

- Install phpmyadmin
- Tools => Quick Add => phpmyadmin-6.0snapshot


B. Pilihan Instalasi
CI4 bisa di-install dengan dua cara utama:
1. Install via Composer (Direkomendasikan)
Kelebihan:
Otomatis setup autoload, dependency, PSR-4.
Mendukung update via composer update.
Standar industri modern.
Langkah-langkah:
```
1. composer create-project codeigniter4/appstarter ci4-sample
2. cd ci4-sample
3. php spark serve

```
Akan tersedia di http://localhost:8080

2. Install Manual (ZIP File)
Cocok untuk environment offline atau dev lokal tanpa composer.
Langkah-langkah:
1. Download dari https://codeigniter.com
2. Ekstrak zip
3. Pindahkan isi folder ke project folder
4. Jalankan lewat terminal: php spark serve

C. Struktur Project

myproject/
├── app/                <- Folder utama aplikasi
├── public/             <- Root web (index.php di sini)
├── system/             <- Core CodeIgniter
├── writable/           <- Temp, logs, uploads
├── tests/              <- Unit & Feature tests
├── .env                <- Config berbasis environment
├── composer.json
└── spark               <- Command Line Tool CI4

📌 Tips Tambahan Selama Migrasi
Jalankan local server pakai:
- php spark serve
- Periksa error di writable/logs/.
- Gunakan php spark routes untuk debugging routing.
- Manfaatkan dokumentasi resmi CI4: https://codeigniter4.github.io/userguide/

