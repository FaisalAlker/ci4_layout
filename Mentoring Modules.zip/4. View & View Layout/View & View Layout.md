## View & View Layout

A. View
1. Create file landing.php
2. Isi dengan HTML Sederhana
3. Buat controller untuk menampilkan View => atau edit Home::index()

B. Layout
1. Create folder Layout di dalam folder View
2. Create file main.php
3. Create folder partials
4. Create file header.php dan footer.php

C. View Layout
1. Edit file landing.php untuk menggunakan layout