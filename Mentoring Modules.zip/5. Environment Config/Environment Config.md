## Setup Awal Environment Configuration

1. Konfigurasi .env
Copy env ke .env
```
CI_ENVIRONMENT = development
database.default.hostname = localhost
database.default.database = ci4db
database.default.username = root
database.default.password = 
database.default.DBDriver = MySQLi
database.default.DBPrefix =
database.default.port = 3306
```

2. Cek dengan Spark CLI
Contoh perintah:
php spark routes → lihat routing
php spark migrate → jalankan migrasi
php spark make:controller Admin
php spark make:model UserModel

4. Verifikasi Berhasil
- Buka di browser: http://localhost:8080/
- Jika muncul: "Welcome to CodeIgniter 4!", artinya instalasi berhasil.
