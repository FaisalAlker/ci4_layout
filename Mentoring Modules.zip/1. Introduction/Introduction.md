## INTRODUCTION

CodeIgniter 3 telah menjadi kerangka kerja (framework) yang ringan dan cepat untuk membangun aplikasi web selama bertahun-tahun. Namun, dengan perubahan kebutuhan industri dan standar modern PHP, CI3 mulai tertinggal dari segi:

Arsitektur yang tidak sepenuhnya berbasis OOP

Kurangnya namespace dan autoloading modern (PSR-4)

Minimnya dukungan untuk testing otomatis (unit test)

Struktur aplikasi yang kurang modular

Tidak ada native support untuk .env, konfigurasi berbasis environment, dan fitur keamanan modern

CodeIgniter 4 hadir sebagai jawaban atas keterbatasan tersebut, dengan pendekatan arsitektur yang modern, lebih terstruktur, dan siap enterprise.

| Area                 | CodeIgniter 3         | CodeIgniter 4            |
| -------------------- | --------------------- | ------------------------ |
| PHP Support          | PHP 5.6+              | PHP 7.4+ (hingga 8.x)    |
| OOP & Namespace      | Parsial               | Full OOP + Namespace     |
| Autoloading          | Manual config         | PSR-4                    |
| Routing              | Konvensi berbasis URL | Routing eksplisit        |
| Struktur Folder      | Bebas                 | Lebih terorganisir       |
| Dependency Injection | Tidak ada             | Ada                      |
| Unit Testing         | Minim                 | Penuh dukungan (PHPUnit) |
| Migration/Seeder     | Harus custom          | Built-in                 |


### Different
1. OOP & Namespace vs Parsial
🔹 CodeIgniter 3 (Parsial OOP, Tanpa Namespace)
CI3 menggunakan konsep OOP, tapi tidak sepenuhnya. Banyak class tidak konsisten menggunakan prinsip OOP (misalnya inheritance tanpa interface/abstraction).

Tidak menggunakan namespace, sehingga semua class harus unik dan harus di-include secara manual atau lewat autoloader-nya sendiri.

Tidak mendukung type hinting atau class dependency injection dengan baik.

Contoh CI3:

``` 
class User_model extends CI_Model {
    public function get_users() {
        return $this->db->get('users')->result();
    }
}
```

🔸 CodeIgniter 4 (Full OOP + Namespace)
CI4 sepenuhnya OOP dan menggunakan namespace sesuai standar PSR (PHP Standard Recommendation).

Kode lebih rapi, modular, dan scalable.

Namespace membantu mencegah class name conflict dan mendukung autoloading modern.

Contoh CI4:
```
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model {
    protected $table = 'users';
}
```

2. Manual Config vs PSR-4
🔹 CodeIgniter 3 (Manual Autoload)
Kita perlu mendaftarkan model, library, helper, dsb. secara manual di application/config/autoload.php.

Setiap file harus berada di folder dengan struktur tetap (tidak fleksibel).

🔸 CodeIgniter 4 (PSR-4 Autoloading)
Menggunakan autoload PSR-4, artinya CI4 akan mencari file berdasarkan namespace dan struktur folder.

Lebih fleksibel, modular, dan otomatis mendeteksi class tanpa daftar satu per satu.

CI4 Config:

```
// app/Config/Autoload.php
$psr4 = [
    'App'         => APPPATH,
    'App\Models'  => APPPATH . 'Models',
];
```

3. Perbedaan Routing
🔹 CI3 (URL konvensi = Routing)
Routing otomatis: URL example.com/user/edit/1 akan memanggil User::edit(1).

Untuk custom routing, harus ditulis manual di routes.php.

🔸 CI4 (Routing Eksplisit & Fleksibel)
Routing lebih powerful dan fleksibel: bisa menentukan method, HTTP verb, filter, dll.

Mendukung route groups, RESTful resource routes, dan closure route.

Contoh CI4:
```
$routes->get('user/edit/(:num)', 'User::edit/$1');
$routes->post('user/create', 'User::create');
```

4. Struktur Folder
🔹 CI3 (Flat & Bebas)
Semua controller di application/controllers/, model di application/models/, dll.

Tidak support struktur modular (HMVC harus di-hack).

🔸 CI4 (Modular & Rapi)
Struktur folder lebih jelas: app/Controllers/, app/Models/, app/Views/, dll.

Mendukung modularisasi (dengan konsep Modules) tanpa hack.

Bisa pisahkan domain (fitur) per modul.

CI4 bisa pakai struktur:
app/
  Controllers/
  Models/
  Views/
  Filters/
  Config/

5. Dependency Injection
🔹 CI3
Tidak support dependency injection secara native.

Harus memanggil $this->load->library() atau $this->load->model() secara manual.

🔸 CI4
Support Dependency Injection (DI) melalui constructor.

Membuat kode lebih testable dan fleksibel.

Contoh:
```
use App\Models\UserModel;

class User extends BaseController {
    protected $userModel;

    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
    }
}
```

6. Unit Testing
🔹 CI3
Tidak built-in.

Harus pasang PHPUnit atau testing framework sendiri secara manual.

Struktur test tidak standar.

🔸 CI4
Sudah siap testing dengan PHPUnit.

Folder tests/ sudah tersedia.

Ada helper FeatureTestCase, CIUnitTestCase, dll.

```
public function testHomePageLoads()
{
    $result = $this->call('get', '/');
    $result->assertOK();
}
```

7. Migration & Seeder
🔹 CI3
Tidak ada fitur bawaan.

Harus pakai package eksternal atau buat sendiri untuk migrasi database.

🔸 CI4
Built-in Migration, Seeder, dan Factory.

Sangat memudahkan otomatisasi pembuatan tabel, data dummy, dll.

Contoh Migration CI4:
```
public function up()
{
    $this->forge->addField([
        'id' => ['type' => 'INT', 'auto_increment' => true],
        'name' => ['type' => 'VARCHAR', 'constraint' => 100],
    ]);
    $this->forge->addKey('id', true);
    $this->forge->createTable('users');
}
```


### Langkah Migrasi Komponen CI3 ke CI4

1. Struktur Proyek

CI3: 
```
application/
  controllers/
  models/
  views/
system/
index.php
```

CI4:
```
app/
  Controllers/
  Models/
  Views/
  Config/
  Filters/
public/
system/
writable/
```

Migrasi:
application/controllers/ → app/Controllers/
application/models/ → app/Models/
application/views/ → app/Views/
Pindahkan index.php ke dalam public/
Semua upload/log/temp data disimpan di writable/

2. Konfigurasi Umum
CI3:
Semua konfigurasi di application/config/ dalam file terpisah.

CI4:
Konfigurasi di app/Config/, setiap konfigurasi menjadi class.
Contoh: app/Config/App.php, Database.php, Routes.php

Migrasi tips:
Bandingkan nilai-nilai penting seperti $baseURL, $indexPage, encryptionKey, dsb.
CI4 punya konfigurasi berbasis .env — cocok untuk multi-environment (dev/staging/prod).

3. Controller
CI3:
```
class User extends CI_Controller {
    public function index() {
        $this->load->view('user');
    }
}

```

CI4:
```
namespace App\Controllers;

class User extends BaseController {
    public function index() {
        return view('user');
    }
}

```

Migrasi tips:
Extend BaseController, bukan CI_Controller.
Gunakan return view() bukan $this->load->view().
Tambahkan namespace App\Controllers; di setiap file controller

4. Model
CI3: 
```
class User_model extends CI_Model {
    public function get_users() {
        return $this->db->get('users')->result();
    }
}

```
CI4:
namespace App\Models;
use CodeIgniter\Model;

class UserModel extends Model {
    protected $table = 'users';
}

Migrasi tips:
Gunakan Model bawaan CI4.
CI4 Model sudah include query builder, validasi, dan soft delete.
Autoload use dan namespace penting.

5. Routing
CI3:
```
$route['user/edit/(:num)'] = 'user/edit/$1';

```

CI4:
```
$routes->get('user/edit/(:num)', 'User::edit/$1');

```

Migrasi tips:
Routing ada di app/Config/Routes.php.
Gunakan get(), post(), match(), atau group() sesuai kebutuhan.
Bisa pakai closure dan RESTful route (resource()).

6. Helper, Library, dan Service
CI3: Semua helper diload manual lewat $this->load->helper('url').
CI4: Gunakan helper('url'); secara global.

Custom Library 
CI3:
```
class MyLibrary {
    public function sayHello() {
        return "Hello";
    }
}

```

CI4:
```
namespace App\Libraries;

class MyLibrary {
    public function sayHello() {
        return "Hello";
    }
}

```

7. Validation
CI3:
```
$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

```
CI4:
```
$validation = \Config\Services::validation();
$rules = ['email' => 'required|valid_email'];
if (!$this->validate($rules)) {
    return redirect()->back()->withInput();
}

```

Migrasi tips:
Validation sekarang bisa via BaseController::validate().
Mendukung custom message, rule set, dan grup rules.

8. Migration dan Seeder
CI3: Tidak ada by default.
CI4 :
Migration:
php spark make:migration CreateUsers
php spark migrate

SEEDER:
php spark make:seeder UserSeeder
php spark db:seed UserSeeder

9. Testing (CI4)
Folder: tests/Feature/, tests/Unit/
```
public function testHomePageLoads() {
    $result = $this->call('get', '/');
    $result->assertOK();
}
```

📌 Tips Tambahan Selama Migrasi
Jalankan local server pakai:
- php spark serve
- Periksa error di writable/logs/.
- Gunakan php spark routes untuk debugging routing.
- Manfaatkan dokumentasi resmi CI4: https://codeigniter4.github.io/userguide/
